cd /home/ubuntu/ElifTech/Bank
NODE_ENV=production npm start
