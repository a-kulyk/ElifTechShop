killall node
