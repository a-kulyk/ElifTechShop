cd /home/ubuntu/
tar xvzf  ElifTechShop.tar.gz ElifTechShop/
